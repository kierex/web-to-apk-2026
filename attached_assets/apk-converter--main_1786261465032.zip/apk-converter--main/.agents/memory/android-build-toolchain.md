---
name: Android build toolchain
description: Runtime requirements and failure modes for native APK compilation.
---

The APK builder must establish a usable Java environment at runtime and pass `JAVA_HOME`/`PATH` to both Android SDK tooling and Gradle. The workspace also needs Gradle plus the Android platform and build-tools packages.

**Why:** Managed workflow processes may start before language or system modules are installed, and `JAVA_HOME` may be unset even when a Java executable is available later.

**How to apply:** On APK build failures mentioning Java, `sdkmanager`, or `gradle ENOENT`, verify the runtime module and Gradle installation, restart the API workflow, and run a real build request through `/api/apk/build`.
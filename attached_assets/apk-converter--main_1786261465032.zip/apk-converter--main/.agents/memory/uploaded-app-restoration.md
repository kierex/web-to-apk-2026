---
name: Uploaded app restoration
description: Artifact bootstrap can create a fresh shell after an uploaded app is staged aside.
---

When an uploaded application is registered as a new artifact, keep a temporary copy of the customized source until artifact registration finishes, then restore the source files into the registered artifact.

**Why:** Artifact registration may scaffold the target directory, replacing or obscuring files that were staged there before registration.

**How to apply:** For future uploaded-app work, inspect the registered artifact after bootstrap and restore only the intended product source/assets while retaining the generated artifact metadata.
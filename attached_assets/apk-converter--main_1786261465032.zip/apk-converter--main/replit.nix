{pkgs}: {
  deps = [
    pkgs.gradle
  ];
}

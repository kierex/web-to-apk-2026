import { Router, type IRouter } from "express";
import { CreateApkBuildBody, GetApkBuildParams } from "@workspace/api-zod";
import { buildApk, createApkBuild, type ApkBuildRecord } from "../lib/apk-builder";

const router: IRouter = Router();
const builds = new Map<string, ApkBuildRecord>();

router.post("/apk/build", async (req, res) => {
  const parsed = CreateApkBuildBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Please check the app details and source code before building." });
    return;
  }

  const created = await createApkBuild(parsed.data);
  builds.set(created.id, created);
  void buildApk(created, parsed.data);
  res.status(202).json({
    id: created.id,
    status: created.status,
    message: created.message,
  });
});

router.get("/apk/build/:id", (req, res) => {
  const parsed = GetApkBuildParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(404).json({ error: "Build not found." });
    return;
  }
  const build = builds.get(parsed.data.id);
  if (!build) {
    res.status(404).json({ error: "Build not found." });
    return;
  }
  res.json({
    id: build.id,
    status: build.status,
    message: build.message,
    fileName: build.fileName,
    downloadUrl: build.downloadUrl,
  });
});

router.get("/apk/build/:id/download", (req, res) => {
  const parsed = GetApkBuildParams.safeParse(req.params);
  const build = parsed.success ? builds.get(parsed.data.id) : undefined;
  if (!build || build.status !== "ready" || !build.filePath || !build.fileName) {
    res.status(404).json({ error: "This APK is not ready to download yet." });
    return;
  }
  res.download(build.filePath, build.fileName, {
    headers: { "Content-Type": "application/vnd.android.package-archive" },
  });
});

export default router;
import { type ChangeEvent, type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  AlertCircle,
  Archive,
  ArrowDownToLine,
  Check,
  CheckCircle2,
  ChevronDown,
  Code2,
  Copy,
  Download,
  ExternalLink,
  FileArchive,
  FileCode2,
  FileUp,
  FolderOpen,
  Hammer,
  LayoutTemplate,
  Loader2,
  MonitorSmartphone,
  MoreHorizontal,
  Package,
  Play,
  RefreshCcw,
  RotateCcw,
  Smartphone,
  Sparkles,
  SunMedium,
  TabletSmartphone,
  Upload,
  XCircle,
} from 'lucide-react';
import {
  getDownloadApkBuildQueryKey,
  getGetApkBuildQueryKey,
  useCreateApkBuild,
  useDownloadApkBuild,
  useGetApkBuild,
  useHealthCheck,
} from '@workspace/api-client-react';
import type { ApkBuildInput, ApkBuildStatus } from '@workspace/api-client-react';
import { Route, Router as WouterRouter, Switch, useLocation } from 'wouter';

const queryClient = new QueryClient();

const starterHtml = `<main class="card">
  <div class="eyebrow">READY TO SHIP</div>
  <h1>Hello, little app.</h1>
  <p>Your web idea has a new home. Tap the button to make it feel alive.</p>
  <button id="action">Make a tiny spark</button>
  <span id="result"></span>
</main>`;

const starterCss = `:root {
  color-scheme: light;
  font-family: system-ui, sans-serif;
}
* { box-sizing: border-box; }
body {
  margin: 0;
  min-height: 100vh;
  display: grid;
  place-items: center;
  padding: 24px;
  background: #f0f1e9;
  color: #18201c;
}
.card { width: min(100%, 380px); }
.eyebrow { font-size: 11px; letter-spacing: .14em; font-weight: 800; color: #6e7b2b; }
h1 { margin: 12px 0 10px; font-size: 38px; letter-spacing: -.06em; }
p { color: #53605a; line-height: 1.6; }
button {
  border: 0; border-radius: 999px; padding: 13px 18px;
  background: #c9ef67; color: #18201c; font-weight: 800;
  cursor: pointer; box-shadow: 0 5px 0 #87a63a;
}
button:active { transform: translateY(3px); box-shadow: 0 2px 0 #87a63a; }
#result { display: block; margin-top: 20px; font-size: 13px; }`;

const starterJs = `document.querySelector("#action").addEventListener("click", () => {
  document.querySelector("#result").textContent = "A small win. Keep going.";
});`;

type EditorTab = 'html' | 'css' | 'javascript';
type Orientation = 'portrait' | 'landscape';
type DelayUnit = 'seconds' | 'minutes';

function crc32(bytes: Uint8Array) {
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let i = 0; i < 8; i += 1) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function makeZip(files: Array<[string, string]>) {
  const encoder = new TextEncoder();
  const local: Uint8Array[] = [];
  const central: Uint8Array[] = [];
  let offset = 0;
  const u16 = (v: number) => new Uint8Array([v & 255, (v >>> 8) & 255]);
  const u32 = (v: number) => new Uint8Array([v & 255, (v >>> 8) & 255, (v >>> 16) & 255, (v >>> 24) & 255]);
  const join = (parts: Uint8Array[]) => {
    const result = new Uint8Array(parts.reduce((n, p) => n + p.length, 0));
    let cursor = 0;
    parts.forEach((part) => { result.set(part, cursor); cursor += part.length; });
    return result;
  };
  files.forEach(([name, text]) => {
    const nameBytes = encoder.encode(name);
    const data = encoder.encode(text);
    const crc = crc32(data);
    const localHeader = join([u32(0x04034b50), u16(20), u16(0), u16(0), u16(0), u16(0), u32(crc), u32(data.length), u32(data.length), u16(nameBytes.length), u16(0), nameBytes, data]);
    local.push(localHeader);
    central.push(join([u32(0x02014b50), u16(20), u16(20), u16(0), u16(0), u16(0), u16(0), u32(crc), u32(data.length), u32(data.length), u16(nameBytes.length), u16(0), u16(0), u16(0), u16(0), u32(0), u32(offset), nameBytes]));
    offset += localHeader.length;
  });
  const localBytes = join(local);
  const centralBytes = join(central);
  return join([localBytes, centralBytes, u32(0x06054b50), u16(0), u16(0), u16(files.length), u16(files.length), u32(centralBytes.length), u32(localBytes.length), u16(0)]);
}

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function escapeHtml(value: string) {
  return value
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function readFileAsDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('The selected image could not be read.'));
    reader.onload = () => resolve(String(reader.result));
    reader.readAsDataURL(file);
  });
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <RoutedErrorBoundary>
            <Switch>
              <Route path="/" component={Studio} />
              <Route component={NotFound} />
            </Switch>
          </RoutedErrorBoundary>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function Studio() {
  const [name, setName] = useState('Pocket Canvas');
  const [packageName, setPackageName] = useState('studio.pocketcanvas.app');
  const [themeColor, setThemeColor] = useState('#C9EF67');
  const [orientation, setOrientation] = useState<Orientation>('portrait');
  const [html, setHtml] = useState(starterHtml);
  const [css, setCss] = useState(starterCss);
  const [javascript, setJavascript] = useState(starterJs);
  const [tab, setTab] = useState<EditorTab>('html');
  const [iconDataUrl, setIconDataUrl] = useState<string | undefined>();
  const [splashDataUrl, setSplashDataUrl] = useState<string | undefined>();
  const [splashBackgroundColor, setSplashBackgroundColor] = useState('#18201C');
  const [splashText, setSplashText] = useState('Loading your app');
  const [splashDelayValue, setSplashDelayValue] = useState('0');
  const [splashDelayUnit, setSplashDelayUnit] = useState<DelayUnit>('seconds');
  const [buildId, setBuildId] = useState('');
  const [buildError, setBuildError] = useState('');
  const [notice, setNotice] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const iconInputRef = useRef<HTMLInputElement>(null);
  const splashInputRef = useRef<HTMLInputElement>(null);

  const health = useHealthCheck();
  const createBuild = useCreateApkBuild();
  const statusQuery = useGetApkBuild(buildId || 'pending', {
    query: {
      enabled: Boolean(buildId),
      queryKey: getGetApkBuildQueryKey(buildId || 'pending'),
      refetchInterval: (query) => {
        const nextStatus = query.state.data?.status;
        return nextStatus === 'ready' || nextStatus === 'failed' ? false : 2500;
      },
    },
  });
  const downloadQuery = useDownloadApkBuild(buildId || 'pending', {
    query: { enabled: false, queryKey: getDownloadApkBuildQueryKey(buildId || 'pending') },
  });

  const status = statusQuery.data as ApkBuildStatus | undefined;
  const splashDelayMs = Math.max(0, Math.min(300000, Math.round((Number(splashDelayValue) || 0) * (splashDelayUnit === 'minutes' ? 60000 : 1000))));
  const splashImage = splashDataUrl || iconDataUrl;
  const developerPhotoUrl = `${import.meta.env.BASE_URL}developer-photo.jpg`;
  const previewSrcDoc = useMemo(() => {
    const splashMarkup = `<div id="studio-splash" style="position:fixed;inset:0;z-index:99999;display:grid;place-items:center;align-content:center;gap:18px;padding:32px;background:${splashBackgroundColor};color:#fff;font-family:system-ui,sans-serif;text-align:center;transition:opacity 220ms ease,visibility 220ms ease">${splashImage ? `<img src="${splashImage}" alt="" style="width:min(42vw,160px);height:min(42vw,160px);object-fit:cover;border-radius:28px;box-shadow:0 14px 34px rgba(0,0,0,.22)">` : ''}<strong>${escapeHtml(splashText || name)}</strong></div>`;
    const splashScript = `<script>(() => { const splash = document.getElementById('studio-splash'); const delay = ${splashDelayMs}; if (!splash || delay <= 0) { splash?.remove(); return; } window.setTimeout(() => { splash.style.opacity = '0'; splash.style.visibility = 'hidden'; splash.style.pointerEvents = 'none'; }, delay); })();<\/script>`;
    return `<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1">${iconDataUrl ? `<link rel="icon" href="${iconDataUrl}">` : ''}<style>${css}</style></head><body>${splashMarkup}${html}<script>${javascript}<\/script>${splashScript}</body></html>`;
  }, [css, html, iconDataUrl, javascript, name, splashBackgroundColor, splashDelayMs, splashImage, splashText]);
  const currentCode = tab === 'html' ? html : tab === 'css' ? css : javascript;
  const setCurrentCode = (value: string) => {
    if (tab === 'html') setHtml(value);
    else if (tab === 'css') setCss(value);
    else setJavascript(value);
  };
  const healthReady = health.data?.status === 'ok' || health.data?.status === 'healthy';
  const working = createBuild.isPending || status?.status === 'queued' || status?.status === 'building';
  const canBuild = name.trim().length > 0 && packageName.includes('.') && html.trim().length > 0;

  useEffect(() => {
    if (status?.status === 'failed') setBuildError(status.message || 'The Android build could not be completed.');
    if (status?.status === 'ready') setNotice('APK is ready. It is waiting in your downloads tray.');
  }, [status?.status, status?.message]);

  const resetCode = () => {
    setHtml(starterHtml);
    setCss(starterCss);
    setJavascript(starterJs);
    setNotice('Starter canvas restored.');
    setBuildError('');
  };

  const handleImagePick = async (event: ChangeEvent<HTMLInputElement>, kind: 'icon' | 'splash') => {
    const file = event.target.files?.[0];
    if (file?.type.startsWith('image/')) {
      const dataUrl = await readFileAsDataUrl(file);
      if (kind === 'icon') setIconDataUrl(dataUrl);
      else setSplashDataUrl(dataUrl);
      setNotice(`${kind === 'icon' ? 'App icon' : 'Splash image'} loaded.`);
    }
    event.target.value = '';
  };

  const createIconFromName = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const context = canvas.getContext('2d');
    if (!context) return;
    context.fillStyle = themeColor;
    context.fillRect(0, 0, canvas.width, canvas.height);
    context.fillStyle = '#18201C';
    context.font = '800 280px system-ui, sans-serif';
    context.textAlign = 'center';
    context.textBaseline = 'middle';
    context.fillText((name.trim()[0] || 'A').toUpperCase(), 256, 272);
    setIconDataUrl(canvas.toDataURL('image/png'));
    setNotice('App icon created from the app name.');
  };

  const handleImport = async (event: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files ?? []);
    for (const file of files) {
      const text = await file.text();
      if (file.name.endsWith('.html')) setHtml(text);
      if (file.name.endsWith('.css')) setCss(text);
      if (file.name.endsWith('.js')) setJavascript(text);
      if (file.type.startsWith('image/')) {
        setIconDataUrl(await readFileAsDataUrl(file));
      }
    }
    if (files.length) setNotice(`${files.length} source file${files.length > 1 ? 's' : ''} imported.`);
    event.target.value = '';
  };

  const copyCurrent = async () => {
    await navigator.clipboard?.writeText(currentCode);
    setNotice(`${tab.toUpperCase()} copied to clipboard.`);
  };

  const exportHtml = () => {
    triggerDownload(new Blob([previewSrcDoc], { type: 'text/html' }), `${name.toLowerCase().replace(/\s+/g, '-') || 'app'}-preview.html`);
    setNotice('HTML preview exported.');
  };

  const exportProject = () => {
    const safeName = name.trim() || 'Pocket Canvas';
    const slug = safeName.toLowerCase().replace(/[^a-z0-9]+/g, '');
    const escapedName = safeName.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
    const files: Array<[string, string]> = [
      ['README.md', `# ${safeName}\n\nA native Android WebView project exported from HTML to APK Studio.\n\nPackage: ${packageName}\nOrientation: ${orientation}\n\nOpen this folder in Android Studio and run the Gradle task \`assembleDebug\` to create an APK.\n`],
      ['app/src/main/assets/index.html', previewSrcDoc],
      ['app/src/main/AndroidManifest.xml', `<manifest xmlns:android="http://schemas.android.com/apk/res/android">
  <uses-permission android:name="android.permission.INTERNET" />
  <application android:theme="@style/AppTheme" android:label="@string/app_name" android:usesCleartextTraffic="true">
    <activity android:name=".MainActivity" android:screenOrientation="${orientation}" android:exported="true">
      <intent-filter>
        <action android:name="android.intent.action.MAIN" />
        <category android:name="android.intent.category.LAUNCHER" />
      </intent-filter>
    </activity>
  </application>
</manifest>`],
      [`app/src/main/java/${packageName.split('.').join('/')}/MainActivity.java`, `package ${packageName};

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
  @Override
  protected void onCreate(Bundle state) {
    super.onCreate(state);
    WebView webView = new WebView(this);
    webView.setWebViewClient(new WebViewClient());
    WebSettings settings = webView.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setAllowFileAccess(true);
    webView.loadUrl("file:///android_asset/index.html");
    setContentView(webView);
  }
}`],
      ['app/src/main/res/values/strings.xml', `<resources><string name="app_name">${escapedName}</string></resources>`],
      ['app/src/main/res/values/colors.xml', `<resources><color name="theme_color">${themeColor}</color></resources>`],
      ['app/src/main/res/values/styles.xml', `<resources>
  <style name="AppTheme" parent="@android:style/Theme.Material.Light.NoActionBar">
    <item name="android:fontFamily">sans</item>
    <item name="android:colorAccent">@color/theme_color</item>
    <item name="android:navigationBarColor">@color/theme_color</item>
  </style>
</resources>`],
      ['settings.gradle', `pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
  repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
  repositories { google(); mavenCentral() }
}
rootProject.name = "${slug || 'android-project'}"
include(":app")`],
      ['build.gradle', `plugins {
  id "com.android.application" version "8.6.1" apply false
}`],
      ['gradle.properties', `org.gradle.jvmargs=-Xmx1536m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true`],
      ['app/build.gradle', `plugins { id "com.android.application" }

android {
  namespace "${packageName}"
  compileSdk 35
  defaultConfig {
    applicationId "${packageName}"
    minSdk 23
    targetSdk 35
    versionCode 1
    versionName "1.0"
  }
}`],
    ];
    triggerDownload(new Blob([makeZip(files)], { type: 'application/zip' }), `${slug || 'android-project'}.zip`);
    setNotice('Android project ZIP exported.');
  };

  const submitBuild = () => {
    if (!canBuild || working) return;
    setBuildError('');
    setNotice('');
    const payload: ApkBuildInput = {
      name: name.trim(),
      packageName: packageName.trim(),
      themeColor,
      orientation,
      html,
      css,
      javascript,
      iconDataUrl,
      splashDataUrl,
      splashBackgroundColor,
      splashText: splashText.trim() || name.trim(),
      splashDelayMs,
    };
    createBuild.mutate({ data: payload }, {
      onSuccess: (created) => {
        setBuildId(created.id);
        setNotice(created.message || 'Build queued. The bench is warming up.');
      },
      onError: (error) => setBuildError(error instanceof Error ? error.message : 'Could not queue the Android build.'),
    });
  };

  const downloadApk = async () => {
    const result = await downloadQuery.refetch();
    if (result.data instanceof Blob) triggerDownload(result.data, status?.fileName || `${name || 'app'}.apk`);
    else if (status?.downloadUrl) window.open(status.downloadUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="studio-shell grain studio-grid flex flex-col">
      <header className="z-20 flex h-[74px] shrink-0 items-center justify-between border-b border-foreground/10 bg-card/90 px-5 backdrop-blur md:px-8">
        <div className="flex items-center gap-3">
          <div className="relative grid size-10 place-items-center rounded-xl bg-primary text-accent shadow-[4px_4px_0_hsl(var(--accent))]">
            <Hammer size={20} strokeWidth={2.5} />
            <span className="absolute -right-1 -top-1 size-2 rounded-full bg-accent blink" />
          </div>
          <div>
            <div className="font-display text-[18px] font-bold tracking-[-.04em]">HTML to APK <span className="text-muted-foreground">/</span> Studio</div>
            <div className="font-mono-ui text-[10px] uppercase tracking-[.18em] text-muted-foreground">a tiny build bench for makers</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div data-testid="status-health" className="hidden items-center gap-2 rounded-full border border-border bg-background px-3 py-1.5 text-xs text-muted-foreground sm:flex">
            <span className={`size-1.5 rounded-full ${health.isLoading ? 'bg-muted-foreground' : healthReady ? 'bg-[#719e21]' : 'bg-destructive'}`} />
            {health.isLoading ? 'checking bench' : healthReady ? 'bench online' : 'offline mode'}
          </div>
          <button data-testid="button-reset-code-top" onClick={resetCode} className="press inline-flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 text-xs font-bold hover:bg-muted">
            <RotateCcw size={14} /> Reset
          </button>
          <button data-testid="button-import-source-top" onClick={() => fileInputRef.current?.click()} className="press inline-flex items-center gap-2 rounded-lg bg-primary px-3 py-2 text-xs font-bold text-primary-foreground hover:opacity-90">
            <Upload size={14} /> Import
          </button>
          <input data-testid="input-import-source" ref={fileInputRef} type="file" multiple accept=".html,.css,.js" className="hidden" onChange={handleImport} />
        </div>
      </header>

      <main className="flex min-h-0 flex-1 flex-col lg:flex-row">
        <section className="flex min-h-[560px] min-w-0 flex-1 flex-col border-b border-foreground/10 lg:min-h-0 lg:border-b-0 lg:border-r">
          <div className="flex items-center justify-between border-b border-foreground/10 bg-card/55 px-5 py-3 md:px-8">
            <div>
              <div className="font-mono-ui text-[10px] font-medium uppercase tracking-[.18em] text-muted-foreground">01 / Source</div>
              <h1 className="font-display mt-1 text-xl font-bold tracking-[-.04em]">Bring the web to life.</h1>
            </div>
            <div className="flex items-center gap-1 rounded-lg border border-border bg-background p-1">
              {(['html', 'css', 'javascript'] as EditorTab[]).map((item) => (
                <button key={item} data-testid={`button-tab-${item}`} onClick={() => setTab(item)} className={`press rounded-md px-3 py-1.5 font-mono-ui text-[10px] uppercase tracking-[.08em] transition ${tab === item ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
                  {item === 'javascript' ? 'JS' : item}
                </button>
              ))}
            </div>
          </div>
          <div className="flex min-h-0 flex-1 flex-col p-5 md:p-8">
            <div className="relative min-h-[360px] flex-1 overflow-hidden rounded-2xl border border-foreground/15 bg-[#202226] shadow-[0_16px_40px_rgba(25,26,33,.16)]">
              <div className="flex h-10 items-center justify-between border-b border-white/10 bg-[#2a2c30] px-4">
                <div className="flex items-center gap-1.5">
                  <span className="size-2 rounded-full bg-[#e8785c]" /><span className="size-2 rounded-full bg-[#efc865]" /><span className="size-2 rounded-full bg-[#83bf55]" />
                </div>
                <div className="font-mono-ui text-[10px] text-white/35">{tab === 'html' ? 'index.html' : tab === 'css' ? 'styles.css' : 'script.js'}</div>
                <button data-testid="button-copy-code" onClick={copyCurrent} className="press text-white/45 transition hover:text-white"><Copy size={14} /></button>
              </div>
              <div className="flex min-h-0 flex-1">
                <div className="hidden w-12 shrink-0 select-none border-r border-white/5 pt-4 text-right font-mono-ui text-[11px] leading-[1.65] text-white/20 sm:block">
                  {currentCode.split('\n').map((_, index) => <div key={index}>{index + 1}</div>)}
                </div>
                <textarea data-testid={`textarea-editor-${tab}`} value={currentCode} onChange={(event) => setCurrentCode(event.target.value)} spellCheck={false} className="min-h-[360px] w-full resize-none bg-transparent p-4 font-mono-ui text-[12px] leading-[1.65] text-[#d8e9b1] outline-none placeholder:text-white/25" />
              </div>
            </div>
            <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-xs text-muted-foreground"><FileCode2 size={14} /> {currentCode.length.toLocaleString()} characters <span className="text-border">/</span> updates are instant</div>
              <button data-testid="button-copy-code-bottom" onClick={copyCurrent} className="inline-flex items-center gap-2 text-xs font-bold text-foreground underline decoration-foreground/20 underline-offset-4 hover:decoration-foreground"><Copy size={13} /> Copy current file</button>
            </div>
          </div>
        </section>

        <section className="relative flex min-h-[610px] min-w-0 flex-1 flex-col bg-background/45">
          <div className="flex items-center justify-between border-b border-foreground/10 bg-card/55 px-5 py-3 md:px-8">
            <div>
              <div className="font-mono-ui text-[10px] font-medium uppercase tracking-[.18em] text-muted-foreground">02 / Preview</div>
              <h2 className="font-display mt-1 text-xl font-bold tracking-[-.04em]">See it on the bench.</h2>
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground"><span className="size-1.5 rounded-full bg-[#719e21]" /> live frame</div>
          </div>
          <div className="flex min-h-0 flex-1 items-center justify-center p-6 md:p-10">
            <div className={`relative transition-all duration-300 ${orientation === 'portrait' ? 'h-[min(66vh,590px)] w-[min(310px,72vw)]' : 'h-[min(330px,46vh)] w-[min(560px,82vw)]'}`}>
              <div className="absolute inset-0 rounded-[2.4rem] bg-[#202226] p-2 shadow-[0_22px_45px_rgba(25,26,33,.26)]">
                <div className="relative h-full w-full overflow-hidden rounded-[1.9rem] bg-[#f4f5ec]">
                  <div className="absolute left-1/2 top-2 z-10 h-5 w-20 -translate-x-1/2 rounded-full bg-[#202226]" />
                  <iframe data-testid="iframe-live-preview" title="Live Android preview" srcDoc={previewSrcDoc} sandbox="allow-scripts" className="h-full w-full border-0" />
                </div>
              </div>
              <div className="absolute -right-3 top-28 h-14 w-1 rounded-r bg-[#34363a]" />
              <div className="absolute -left-3 top-40 h-9 w-1 rounded-l bg-[#34363a]" />
            </div>
          </div>
          <div className="flex items-center justify-between border-t border-foreground/10 bg-card/55 px-5 py-3 md:px-8">
            <div className="font-mono-ui text-[10px] uppercase tracking-[.12em] text-muted-foreground">{orientation} · webview 1.0</div>
            <button data-testid="button-open-preview" onClick={() => window.open(URL.createObjectURL(new Blob([previewSrcDoc], { type: 'text/html' })), '_blank', 'noopener,noreferrer')} className="inline-flex items-center gap-1.5 text-xs font-bold hover:text-muted-foreground"><ExternalLink size={13} /> Open preview</button>
          </div>
        </section>
      </main>

      <section className="border-t border-foreground/10 bg-card px-5 py-5 md:px-8 md:py-6">
        <div className="mx-auto grid max-w-[1500px] gap-6 xl:grid-cols-[1.15fr_1fr_1fr]">
          <div className="pop-in">
            <div className="mb-4 flex items-center gap-2"><span className="grid size-7 place-items-center rounded-lg bg-accent font-display text-sm font-bold">03</span><h2 className="font-display text-lg font-bold tracking-[-.04em]">Give it a name.</h2></div>
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="block"><span className="mb-1.5 block font-mono-ui text-[10px] uppercase tracking-[.12em] text-muted-foreground">App name</span><input data-testid="input-app-name" value={name} onChange={(event) => setName(event.target.value)} maxLength={50} className="w-full rounded-xl border border-input bg-background px-3.5 py-3 text-sm font-semibold outline-none transition focus:border-ring focus:ring-2 focus:ring-ring/15" /></label>
              <label className="block"><span className="mb-1.5 block font-mono-ui text-[10px] uppercase tracking-[.12em] text-muted-foreground">Package name</span><input data-testid="input-package-name" value={packageName} onChange={(event) => setPackageName(event.target.value)} className="w-full rounded-xl border border-input bg-background px-3.5 py-3 font-mono-ui text-xs outline-none transition focus:border-ring focus:ring-2 focus:ring-ring/15" /></label>
            </div>
            <div className="mt-4 flex flex-wrap items-center gap-4">
              <div><span className="mb-2 block font-mono-ui text-[10px] uppercase tracking-[.12em] text-muted-foreground">Theme color</span><div className="flex items-center gap-2"><label className="relative size-9 cursor-pointer overflow-hidden rounded-full border-2 border-background shadow-[0_0_0_1px_hsl(var(--border))]"><input data-testid="input-theme-color" type="color" value={themeColor} onChange={(event) => setThemeColor(event.target.value.toUpperCase())} className="absolute -inset-2 size-14 cursor-pointer" /><span className="sr-only">Pick theme color</span></label><span data-testid="text-theme-color" className="font-mono-ui text-xs">{themeColor}</span></div></div>
              <div><span className="mb-2 block font-mono-ui text-[10px] uppercase tracking-[.12em] text-muted-foreground">Orientation</span><div className="flex rounded-xl border border-input bg-background p-1">{(['portrait', 'landscape'] as Orientation[]).map((item) => <button key={item} data-testid={`button-orientation-${item}`} onClick={() => setOrientation(item)} className={`press inline-flex items-center gap-1.5 rounded-lg px-3 py-2 font-mono-ui text-[10px] uppercase tracking-[.07em] ${orientation === item ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}>{item === 'portrait' ? <Smartphone size={13} /> : <TabletSmartphone size={13} />}{item}</button>)}</div></div>
               <div className="ml-auto"><span className="mb-2 block font-mono-ui text-[10px] uppercase tracking-[.12em] text-muted-foreground">App icon</span><div className="flex flex-wrap gap-2"><input ref={iconInputRef} type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(event) => void handleImagePick(event, 'icon')} /><button data-testid="button-import-icon" onClick={() => iconInputRef.current?.click()} className="inline-flex items-center gap-2 rounded-xl border border-dashed border-foreground/25 bg-background px-3 py-2 text-xs font-bold hover:border-foreground/50"><FolderOpen size={14} /> {iconDataUrl ? 'Change image' : 'Upload image'}</button><button data-testid="button-create-icon" onClick={createIconFromName} className="inline-flex items-center gap-2 rounded-xl border border-border bg-background px-3 py-2 text-xs font-bold hover:bg-muted"><Sparkles size={14} /> Create</button></div></div>
            </div>
             <div className="mt-4 grid gap-3 border-t border-border pt-4 sm:grid-cols-2">
               <div className="sm:col-span-2 flex items-center justify-between gap-3"><div><span className="block font-mono-ui text-[10px] uppercase tracking-[.12em] text-muted-foreground">Splash screen</span><span className="mt-1 block text-xs text-muted-foreground">Optional image shown before your app starts.</span></div><input ref={splashInputRef} type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(event) => void handleImagePick(event, 'splash')} /><button data-testid="button-import-splash" onClick={() => splashInputRef.current?.click()} className="inline-flex shrink-0 items-center gap-2 rounded-xl border border-dashed border-foreground/25 bg-background px-3 py-2 text-xs font-bold hover:border-foreground/50"><FolderOpen size={14} /> {splashDataUrl ? 'Change image' : 'Upload image'}</button></div>
               <label className="block"><span className="mb-1.5 block font-mono-ui text-[10px] uppercase tracking-[.12em] text-muted-foreground">Splash text</span><input data-testid="input-splash-text" value={splashText} onChange={(event) => setSplashText(event.target.value)} maxLength={80} className="w-full rounded-xl border border-input bg-background px-3.5 py-3 text-sm outline-none transition focus:border-ring focus:ring-2 focus:ring-ring/15" /></label>
               <div><span className="mb-1.5 block font-mono-ui text-[10px] uppercase tracking-[.12em] text-muted-foreground">Splash background</span><div className="flex items-center gap-2"><label className="relative size-9 cursor-pointer overflow-hidden rounded-full border-2 border-background shadow-[0_0_0_1px_hsl(var(--border))]"><input data-testid="input-splash-background" type="color" value={splashBackgroundColor} onChange={(event) => setSplashBackgroundColor(event.target.value.toUpperCase())} className="absolute -inset-2 size-14 cursor-pointer" /><span className="sr-only">Pick splash background color</span></label><span className="font-mono-ui text-xs">{splashBackgroundColor}</span></div></div>
               <label className="block"><span className="mb-1.5 block font-mono-ui text-[10px] uppercase tracking-[.12em] text-muted-foreground">Show splash for</span><div className="flex gap-2"><input data-testid="input-splash-delay" type="number" min="0" max={splashDelayUnit === 'minutes' ? 5 : 300} step="1" value={splashDelayValue} onChange={(event) => setSplashDelayValue(event.target.value)} className="min-w-0 flex-1 rounded-xl border border-input bg-background px-3.5 py-3 text-sm outline-none transition focus:border-ring focus:ring-2 focus:ring-ring/15" /><select data-testid="select-splash-delay-unit" value={splashDelayUnit} onChange={(event) => setSplashDelayUnit(event.target.value as DelayUnit)} className="rounded-xl border border-input bg-background px-3 py-3 text-sm outline-none focus:border-ring focus:ring-2 focus:ring-ring/15"><option value="seconds">seconds</option><option value="minutes">minutes</option></select></div></label>
             </div>
          </div>

          <div className="pop-in-delay border-t border-border pt-5 xl:border-l xl:border-t-0 xl:pl-6 xl:pt-0">
            <div className="mb-4 flex items-center gap-2"><span className="grid size-7 place-items-center rounded-lg bg-secondary font-display text-sm font-bold">04</span><h2 className="font-display text-lg font-bold tracking-[-.04em]">Take it with you.</h2></div>
            <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-1">
              <button data-testid="button-export-html" onClick={exportHtml} className="lift press flex items-center justify-between rounded-xl border border-border bg-background px-4 py-3 text-left"><span className="flex items-center gap-3"><span className="grid size-8 place-items-center rounded-lg bg-muted"><FileCode2 size={16} /></span><span><span className="block text-sm font-bold">Export HTML preview</span><span className="block text-[11px] text-muted-foreground">A portable single file</span></span></span><ArrowDownToLine size={15} className="text-muted-foreground" /></button>
              <button data-testid="button-export-project" onClick={exportProject} className="lift press flex items-center justify-between rounded-xl border border-border bg-background px-4 py-3 text-left"><span className="flex items-center gap-3"><span className="grid size-8 place-items-center rounded-lg bg-muted"><Archive size={16} /></span><span><span className="block text-sm font-bold">Export Android project</span><span className="block text-[11px] text-muted-foreground">Source ZIP for Android Studio</span></span></span><ArrowDownToLine size={15} className="text-muted-foreground" /></button>
            </div>
          </div>

          <div className="pop-in-delay-2 border-t border-border pt-5 xl:border-l xl:border-t-0 xl:pl-6 xl:pt-0">
            <div className="mb-4 flex items-center gap-2"><span className="grid size-7 place-items-center rounded-lg bg-primary font-display text-sm font-bold text-primary-foreground">05</span><h2 className="font-display text-lg font-bold tracking-[-.04em]">Build the real thing.</h2></div>
            <div className="rounded-2xl bg-primary p-4 text-primary-foreground shadow-[5px_5px_0_hsl(var(--accent))]">
              {working ? <div data-testid="status-build-working" className="flex items-center gap-3"><Loader2 size={18} className="animate-spin text-accent" /><div><div className="text-sm font-bold">{status?.status === 'building' ? 'Android is compiling…' : 'Build queued…'}</div><div className="mt-1 text-[11px] text-primary-foreground/60">{status?.message || 'Your source is on the bench.'}</div></div></div> : status?.status === 'ready' ? <div data-testid="status-build-ready" className="flex items-center gap-3"><CheckCircle2 size={20} className="text-accent" /><div className="min-w-0 flex-1"><div className="text-sm font-bold">Your APK is ready.</div><div className="mt-1 truncate font-mono-ui text-[10px] text-primary-foreground/60">{status.fileName || 'android-build.apk'}</div></div><button data-testid="button-download-apk" onClick={downloadApk} disabled={downloadQuery.isFetching} className="press inline-flex items-center gap-1.5 rounded-lg bg-accent px-3 py-2 text-xs font-bold text-accent-foreground hover:brightness-95 disabled:opacity-60"><Download size={14} /> {downloadQuery.isFetching ? 'Fetching' : 'Download'}</button></div> : <div><div className="mb-3 flex items-center justify-between"><span className="font-mono-ui text-[10px] uppercase tracking-[.15em] text-primary-foreground/60">No account. No ceremony.</span><Sparkles size={16} className="text-accent" /></div><button data-testid="button-build-apk" onClick={submitBuild} disabled={!canBuild} className="press flex w-full items-center justify-center gap-2 rounded-xl bg-accent px-4 py-3 text-sm font-extrabold text-accent-foreground transition hover:brightness-95 disabled:cursor-not-allowed disabled:opacity-45"><Play size={15} fill="currentColor" /> Build APK</button></div>}
            </div>
            {buildError && <div data-testid="status-build-error" className="mt-3 flex items-start gap-2 rounded-xl border border-destructive/30 bg-destructive/10 p-3 text-xs text-destructive"><AlertCircle size={14} className="mt-0.5 shrink-0" /><span>{buildError}</span><button data-testid="button-dismiss-build-error" onClick={() => setBuildError('')} className="ml-auto"><XCircle size={14} /></button></div>}
            {notice && !buildError && <div data-testid="status-studio-notice" className="mt-3 flex items-center gap-2 text-xs font-semibold text-muted-foreground"><Check size={14} className="text-[#719e21]" /> {notice}</div>}
          </div>
        </div>
      </section>
      <footer className="border-t border-foreground/10 bg-primary px-5 py-5 text-primary-foreground md:px-8">
        <div className="mx-auto flex max-w-[1500px] flex-wrap items-center gap-4">
          <img src={developerPhotoUrl} alt="Vernie Esgana" className="size-12 rounded-full object-cover ring-2 ring-accent/70" />
          <div className="mr-auto">
            <div className="font-display text-sm font-bold">Developed by Vernie Esgana</div>
            <div className="mt-1 font-mono-ui text-[10px] uppercase tracking-[.14em] text-primary-foreground/60">BSIT 3 NORTH</div>
          </div>
          <a data-testid="link-developer-facebook" href="https://www.facebook.com/profile.php?id=100003787922848" target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 rounded-xl bg-accent px-4 py-2.5 text-xs font-extrabold text-accent-foreground transition hover:brightness-95"><ExternalLink size={14} /> Follow on Facebook</a>
        </div>
      </footer>
    </div>
  );
}

export default App;